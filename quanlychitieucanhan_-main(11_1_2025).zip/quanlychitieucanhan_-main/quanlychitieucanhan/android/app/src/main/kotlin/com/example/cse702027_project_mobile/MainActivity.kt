package com.example.cse702027_project_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
